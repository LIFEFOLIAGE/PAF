insert into foliage2.flgabilitazioni_tab (tipo_auth) values
	 ('PROP'),
	 ('PROF'),
	 ('ISTR'),
	 ('DIRI'),
	 ('RESP'),
	 ('SORV'),
	 ('AMMI');
