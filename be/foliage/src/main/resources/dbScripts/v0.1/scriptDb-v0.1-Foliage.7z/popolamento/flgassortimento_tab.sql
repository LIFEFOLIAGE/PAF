insert into FLGASSORTIMENTO_TAB(DESTINAZIONE_USO, DESC_ASSORTIMENTO, NOME_ASSORTIMENTO)
values ('A fini energetici','Legna da ardere e carbone', 'LEGNA'),
	('A fini energetici','Cippato per combustibile (biomasse)', 'COMBUSTIBILE'),
	('Per lavorazione indrustiale','Tronchi (travame, trancia da sega, trancia da sfoglia)', 'TRONCHI'),
	('Per lavorazione indrustiale','Cippato per cellulosa', 'CELLULOSA'),
	('Per lavorazione indrustiale','Altro', 'ALTRO');