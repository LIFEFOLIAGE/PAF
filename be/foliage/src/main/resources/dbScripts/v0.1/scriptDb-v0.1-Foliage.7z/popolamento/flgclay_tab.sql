insert into foliage2.flgclay_tab (id_clay,desc_clay,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali) values
	 (1,'ACQUE',NULL,1,NULL,NULL,NULL,NULL,'2022-08-17',NULL),
	 (2,'STRADE',NULL,1,'admin','2022-09-22',NULL,NULL,'2022-09-22',NULL),
	 (3,'FABBRICATI',NULL,1,'admin','2022-09-22',NULL,NULL,'2022-09-22',NULL);
