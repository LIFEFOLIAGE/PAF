insert into foliage2.flggove_tab (id_gove,desc_gove,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali,codi_regi,is_fustaia,is_ceduo) values
	 (1,'Fustaia',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12',true,false),
	 (2,'Ceduo',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12',false,true);
