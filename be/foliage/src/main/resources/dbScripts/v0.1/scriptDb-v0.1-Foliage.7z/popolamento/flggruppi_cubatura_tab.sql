insert into FLGGRUPPI_CUBATURA_TAB(COD_GRUPPO_CUBATURA, DESC_GRUPPO_CUBATURA)
values ('PRES', 'Presenti'),
	('RILASCIA', 'Da Rilasciare al Taglio'),
	('TAGLIA', 'Da Tagliare');
