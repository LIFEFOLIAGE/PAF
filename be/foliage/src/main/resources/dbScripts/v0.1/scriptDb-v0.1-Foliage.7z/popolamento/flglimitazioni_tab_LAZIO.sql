insert into foliage2.flglimitazioni_tab (cod_limitazione,desc_limitazione) values
	 ('NAT2K_4000MQ','Avvisi il taglio boschivo indicato ricade nei limiti del Sito Natura 2000. gli interventi di fine turno sono ammessi per una superficie non superiore a 4.000 m2 (art. 53, c. 2, lettera f)'),
	 ('GENERICA_SOPRA_SOGLIA','La particella forestale ricade in aree vincolate. E’ responsabilità del professionista individuare il tipo di istanza corretto tra istanza sopra soglia e istanza in deroga.');
