insert into foliage2.flgnprp_tab (id_nprp,desc_nprp,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali,codi_regi) values
	 (3,'P. Pubblica',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (4,'P. Privata',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (5,'P. Collettiva',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (6,'Enti Morali',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (7,'Fondazione',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12');
