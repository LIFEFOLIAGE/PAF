insert into foliage2.flgprof_tab (id_profilo,descrizione,tipo_auth,tipo_ambito) values
	 (6,'Istruttore','ISTR','TERRITORIALE'),
	 (7,'Dirigente','DIRI','TERRITORIALE'),
	 (8,'Operatore di sportello','PROF','TERRITORIALE'),
	 (9,'Carabiniere forestale','SORV','CASERMA'),
	 (10,'Guardia parco aree protette','SORV','PARCO'),
	 (13,'Responsabile Carabinieri','RESP','CASERMA'),
	 (14,'Responsabile Parco','RESP','PARCO'),
	 (1,'Proprietario e gestore forestale','PROP','GENERICO'),
	 (2,'Professionista forestale','PROF','GENERICO'),
	 (11,'Responsabile di Sede','RESP','TERRITORIALE'),
	 (12,'Responsabile del Servizio','AMMI','GENERICO');
