insert into foliage2.flgsspr_tab (id_sspr,desc_sspr,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali,codi_regi) values
	 (1,'Coetaneo',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (2,'Disetaneo',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (3,'Irregolare',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (4,'Soprassuolo di età elevata',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (5,'Soprassuolo transitorio e/o in conversione',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (6,'Rimboschimento',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12');
