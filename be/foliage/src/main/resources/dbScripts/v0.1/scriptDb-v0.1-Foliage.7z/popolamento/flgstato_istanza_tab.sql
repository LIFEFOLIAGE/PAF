insert into foliage2.flgstato_istanza_tab (id_stato,cod_stato,desc_stato) values
	 (1,'COMPILAZIONE','In Compilazione'),
	 (2,'PRESENTATA','Presentata'),
	 (4,'APPROVATA','Approvata'),
	 (5,'RESPINTA','Respinta'),
	 (3,'ISTRUTTORIA','In Valutazione');
