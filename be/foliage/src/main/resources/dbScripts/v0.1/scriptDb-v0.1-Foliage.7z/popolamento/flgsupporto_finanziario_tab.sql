insert into FLGSUPPORTO_FINANZIARIO_TAB (COD_TIPO_FINANZIAMENTO, DESC_TIPO_FINANZIAMENTO)
	values (1, 'Fondi del Piano di Sviluppo Rurale'),
		(2, 'Fondi di progetti LIFE'),
		(3, 'Fondi Nazionali'),
		(4, 'Fondi Regionali'),
		(5, 'Altri fondi Europei (eg. horizon 2020) '),
		(6, 'Altri finanziamenti'),
		(7, 'Nessun finanziamento');
