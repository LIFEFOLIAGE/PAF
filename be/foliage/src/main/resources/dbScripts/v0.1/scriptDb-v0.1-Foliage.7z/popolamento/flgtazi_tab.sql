insert into foliage2.flgtazi_tab (id_tazi,desc_tazi,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali,codi_regi) values
	 (1,'Proprieta',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (2,'Azienda',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (3,'Boschi Silenti',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12');
