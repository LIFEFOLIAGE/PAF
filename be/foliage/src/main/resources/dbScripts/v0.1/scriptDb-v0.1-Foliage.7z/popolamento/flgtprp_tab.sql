insert into foliage2.flgtprp_tab (id_tprp,desc_tprp,note,flag_valido,user_ins,data_ins,user_upd,data_upd,data_ini_vali,data_fine_vali,codi_regi) values
	 (1,'Esclusiva',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12'),
	 (2,'Multipla',NULL,1,'admin','2021-11-04',NULL,NULL,'2021-11-04',NULL,'12');
