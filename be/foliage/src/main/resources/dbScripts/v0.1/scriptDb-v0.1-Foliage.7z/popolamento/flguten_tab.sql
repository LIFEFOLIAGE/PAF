insert into foliage2.flguten_tab(id_uten, user_name, flag_accettazione)
	OVERRIDING SYSTEM VALUE values(-1, 'UTENTE_AUTOACCETTAZIONE', false);
