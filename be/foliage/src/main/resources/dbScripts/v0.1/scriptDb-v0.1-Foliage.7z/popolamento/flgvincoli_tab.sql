insert into foliage2.flgvincoli_tab (cod_vincolo,desc_vincolo,gruppo) values
	 ('NAT2K','Natura 2000','Aree Protette'),
	 ('HABITAT_PRIOR','Habitat Prioritari',NULL),
	 ('PAI_FRANE','PAI Rischio Idrogeologico - Frane','PAI - Rischio Idrogeologico'),
	 ('PAI_VALANGHE','PAI Rischio Idrogeologico - Valanghe','PAI - Rischio Idrogeologico'),
	 ('PAI_ALLUVIONI','PAI Rischio Idrogeologico - Alluvioni','PAI - Rischio Idrogeologico'),
	 ('AREE_PROTETTE','Aree Protette','Aree Protette');
