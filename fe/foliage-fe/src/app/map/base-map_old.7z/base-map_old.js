import { pointerMove, singleClick } from 'ol/events/condition';
//import { get as getProjection } from 'ol/proj';
//import VectorSource from 'ol/source/Vector';
//import VectorLayer from 'ol/layer/Vector';
//import { Select, defaults as defaultInteractions } from 'ol/interaction';
//import {Style, Stroke, Text, Fill } from 'ol/style';


//import  { Map, Collection, Feature, Overlay, View } from 'ol';
import * as ol from 'ol';
import * as olStyle from 'ol/style';
import * as olLayer from 'ol/layer';
import * as olSource from 'ol/source';
import GeoJSON from 'ol/format/GeoJSON';
import GML3 from 'ol/format/GML3';
import OSM from 'ol/source/OSM';

import TileWMS from 'ol/source/TileWMS';
import { createXYZ } from 'ol/tilegrid';
import { tile } from 'ol/loadingstrategy';
// import * as olEvents from 'ol/events';
// import * as olEvent from 'ol/events/Event';
// import * as olEventCondition from 'ol/events/condition';
//import * as olFormat from 'ol/format';
import MapBrowserEventType from 'ol/MapBrowserEventType';
import * as olProj from 'ol/proj';
import * as olInteraction from 'ol/interaction';
import { extend } from 'ol/extent';
//import TileLayer from 'ol/layer/Tile';
//import XYZ from 'ol/source/XYZ';

import WKT from 'ol/format/WKT';



import {
	Point,
	LineString,
	LinearRing,
	Polygon,
	MultiPoint,
	MultiLineString,
	MultiPolygon,
	GeometryCollection
} from "ol/geom";

import proj4 from 'proj4';

import { register } from 'ol/proj/proj4';


const format = new WKT();



//ol.layers = ollayers;

proj4.defs(
	"EPSG:3004",
	"+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +towgs84=-104.1,-49.1,-9.9,0.971,-2.917,0.714,-11.68 +units=m +no_defs"
);
proj4.defs(
	"EPSG:3003",
	"+proj=tmerc +lat_0=0 +lon_0=9 +k=0.9996 +x_0=1500000 +y_0=0 +ellps=intl +towgs84=-104.1,-49.1,-9.9,0.971,-2.917,0.714,-11.68 +units=m +no_defs"
);
proj4.defs(
	"EPSG:3044",
	"+proj=utm +zone=32 +ellps=GRS80 +units=m +no_defs "
);
proj4.defs(
	"EPSG:3046",
	"+proj=utm +zone=34 +ellps=GRS80 +units=m +no_defs "
);
proj4.defs(
	"EPSG:6706",
	"+proj=longlat +ellps=GRS80 +no_defs +type=crs"
);
proj4.defs(
	"EPSG:4258",
	"+proj=longlat +ellps=GRS80 +no_defs +type=crs"
);
proj4.defs(
	"EPSG:32633",
	"+proj=utm +zone=33 +datum=WGS84 +units=m +no_defs +type=crs"
);
proj4.defs(
	"EPSG:32632",
	"+proj=utm +zone=32 +datum=WGS84 +units=m +no_defs +type=crs"
);
proj4.defs(
	"EPSG:6707",
	"+proj=utm +zone=32 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs +type=crs"
);
// proj4.defs(
// 	"EPSG:6706",
// 	"+proj=longlat +ellps=GRS80 +no_defs +type=crs"
// );
// const proj3003 = olProj.get("EPSG:3003");
// const proj3004 = olProj.get("EPSG:3004");
register(proj4);


//const projections = {};
// projections["3003"] = proj3003;
// projections["3004"] = proj3004;



export function hexToRGB(hex, alpha) {
	var r = parseInt(hex.slice(1, 3), 16),
		g = parseInt(hex.slice(3, 5), 16),
		b = parseInt(hex.slice(5, 7), 16);

	if (alpha) {
		return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
	} else {
		return "rgb(" + r + ", " + g + ", " + b + ")";
	}
}

const layerStile = {
	Color: '#0000FF',
	TextColor: '#FFFFFF',
};

function getDotStyle(color) {
	return new olStyle.Style(
		{
			image: new olStyle.Circle(
				{
					radius: 3,
					fill: new olStyle.Fill(
						{
							color: color,
						}
					),
				}
			),
			geometry: function (feature) {
				// return the coordinates of the first ring of the polygon
				const geom = feature.getGeometry();
				const type = geom.getType();
				//if (type == "Point" || ty)
				switch (type) {
					case "Point": return geom;
					case "MultiPoint": return geom;
					case "GeometryCollection": {
						const geoms = geom.getGeometries();
						const coordinates = geoms.map(
							geom => {
								//const coordinates = geom.getCoordinates();
								const gType = geom.getType();
								const coord = geom.getCoordinates();
								switch (gType) {
									case "Point": return [coord];
									case "LineString": return coord;
									case "Polygon": return coord.reduce(
										(pvRes, curr) => {
											if (pvRes) {
												return pvRes.concat(curr)
											}
											else {
												return curr;
											}
										}
									);
									default: {
										throw new Error(`Geometria non gestita ${gType}`);
									}
								}
							}
						);
						const flatCoordinates = coordinates.reduce(
							(pvRes, curr) => {
								if (pvRes) {
									return pvRes.concat(curr)
								}
								else {
									return curr;
								}
							}
						)

						if (flatCoordinates.length > 1) {
							return new MultiPoint(flatCoordinates, "XY");
						}
						else {
							return new Point(flatCoordinates, "XY");
						}
					};
					case "MultiPolygon": {
						const geoms = geom.getPolygons();
						const coordinates = geoms.map(
							geom => geom.getCoordinates().reduce(
								(pvRes, curr) => {
									if (pvRes) {
										return pvRes.concat(curr)
									}
									else {
										return curr;
									}
								}
							)
						);
						const flatCoordinates = coordinates.reduce(
							(pvRes, curr) => {
								if (pvRes) {
									return pvRes.concat(curr)
								}
								else {
									return curr;
								}
							}
						);
						if (flatCoordinates.length > 1) {
							return new MultiPoint(flatCoordinates, "XY");
						}
						else {
							return new Point(flatCoordinates, "XY");
						}
					};
					default: {
						const coordinates = geom.getCoordinates();
						const flatCoordinates = coordinates.reduce(
							(pvRes, curr) => {
								if (pvRes) {
									return pvRes.concat(curr)
								}
								else {
									return curr;
								}
							}
						);
						if (flatCoordinates.length > 1) {
							return new MultiPoint(flatCoordinates, "XY");
						}
						else {
							return new Point(flatCoordinates, "XY");
						}
					}
				}
			},
		}
	);
}
//const dotStyle = getDotStyle();

export const stylesMap = {
	highlighted: (feature) => [
		new olStyle.Style(
			{
				fill: new olStyle.Fill({
					color: hexToRGB(layerStile.Color, 0.8)
				}),
				stroke: new olStyle.Stroke({
					color: layerStile.Color,
					width: 1
				}),
				text: new olStyle.Text({
					font: '12px Calibri,sans-serif',
					fill: new olStyle.Fill({ color: '#000000' }),
					stroke: new olStyle.Stroke({
						color: '#FFFFFF', width: 2
					}),
					offsetX: 5,
					offsetY: 5,
					text: feature.get('lab')
				})
			}
		),
		getDotStyle('#F0F000')
	],
	normal: (feature) => [
		new olStyle.Style(
			{
				fill: new olStyle.Fill({
					color: hexToRGB(layerStile.Color, 0.1)
				}),
				stroke: new olStyle.Stroke({
					color: layerStile.Color,
					width: 1
				}),
				text: new olStyle.Text({
					font: '12px Calibri,sans-serif',
					fill: new olStyle.Fill({ color: '#000000' }),
					stroke: new olStyle.Stroke({
						color: '#FFFFFF', width: 2
					}),
					offsetX: 5,
					offsetY: 5,
					text: feature.get('lab')
				})
			}
		),
		getDotStyle(layerStile.Color)
	],
	selected: (feature) => [
		new olStyle.Style(
			{
				fill: new olStyle.Fill({
					color: hexToRGB('#FFFFFF', 0.2)
				}),
				stroke: new olStyle.Stroke({
					color: layerStile.Color,
					width: 2
				}),
				text: new olStyle.Text({
					font: '12px Calibri,sans-serif',
					fill: new olStyle.Fill({ color: '#000000' }),
					stroke: new olStyle.Stroke({
						color: '#FFFFFF', width: 2
					}),
					offsetX: 5,
					offsetY: 5,
					text: feature.get('lab')
				})
			}
		),
		getDotStyle('#00F000')
	]
};

export class BaseMap {
	inquadro = undefined;
	mainSource = [];
	mainLayer = undefined;
	originalFeatures = [];
	features = [];

	selFeatures = new ol.Collection();
	highFeatures = new ol.Collection();

	selectedFeature = undefined;
	viewOverlay = false;
	view = undefined;
	popupOverlay = undefined;
	mapController = undefined;
	currentInteractions = [];

	setInteractions(interactions) {
		this.currentInteractions.forEach(
			(i) => {
				this.mapController.removeInteraction(i);
			}
		);

		this.currentInteractions = interactions;

		this.currentInteractions.forEach(
			(i) => {
				this.mapController.addInteraction(i);
			}
		);
	}

	constructor(selectCb, highilightCb) {
		this.selectCb = selectCb;
		this.highilightCb = highilightCb;
		this.selFeatures = new ol.Collection();
		this.mainSource = new olSource.Vector({ wrapX: false });
		this.mainLayer = new olLayer.Vector(
			{
				source: this.mainSource,
				visible: true,
				style: stylesMap['normal']
			}
		);
		this.select = new olInteraction.Select(
			{
				condition: (mapBrowserEvent) => {
					// impedisce selezioni con doppio click e selezioni multiple (con tasto shift)
					const orEvent = mapBrowserEvent.originalEvent;
					return (
						mapBrowserEvent.type == MapBrowserEventType.SINGLECLICK
						&& !(orEvent.altKey || orEvent.ctrlKey || orEvent.shiftKey)
					);
				},
				layers: [this.mainLayer],
				features: this.selFeatures,
				style: stylesMap["selected"]
			}
		);
		this.highlight = new olInteraction.Select(
			{
				condition: pointerMove,
				layers: [this.mainLayer],
				features: this.highFeatures,
				filter: (feat, layer) => {
					// impedisce di evidenziare elementi già in selezione
					const arr = this.selFeatures.getArray();
					if (arr) {
						const res = (arr.find(f => f == feat) == null);
						return res;
					}
					else {
						return true;
					}
				},
				style: stylesMap["highlighted"]
			}
		);

		if (selectCb && typeof (selectCb) == 'function') {
			this.select.on(
				'select',
				(e) => {
					selectCb(e.selected, e.deselected);
				}
			);
		}
		this.select.on(
			'select',
			(e) => {
				this.mostraOverlay(undefined);
				this.selectedFeature = (e.selected && e.selected.length == 1) ? e.selected[0] : undefined;
				//this.gotoElement(element);
			}
		);
		if (highilightCb && typeof (highilightCb) == 'function') {
			this.highlight.on(
				'select',
				(e) => {
					highilightCb(e.selected, e.deselected);
				}
			);
		}
	}

	getInteriorPoint(g) {
		const geometryType = g.getType();
		switch (geometryType) {
			case 'Polygon': return g.getInteriorPoint(); break;
			case 'MultiPolygon': return this.getInteriorPoint(g.getPolygon(0)); break;
			case 'Point': return g; break;
			case 'MultiPoint': return this.getInteriorPoint(g.getPoint(0)); break;
			case 'LineString': return new Point(g.getFirstCoordinate(), "XY"); break;
			case 'MultiLineString': return this.getInteriorPoint(g.getLineString(0)); break;
			case 'GeometryCollection': return this.getInteriorPoint(g.getGeometries()[0]); break;
			default: {
				throw new Error(`Geometria non gestita ${geometryType}`);
			}
		}
	}

	updateData(conf, dati) {
		if (conf && dati && Array.isArray(dati)) {
			if (conf.mappa) {
				const shapeField = conf.mappa.shape.attribute;
				const labelField = conf.mappa.shape.label;
				const shapeSrid = conf.mappa.shape.srid;
				const viewSrid = conf.mappa.view.srid;
				this.originalFeatures = dati.map(
					(dati, idx) => {
						if (dati != undefined) {
							const g = format.readGeometry(
								dati[shapeField], { dataProjection: shapeSrid, featureProjection: viewSrid }
							);
							const lab = labelField ? dati[labelField].toString() : undefined;

							const interiorPoint = this.getInteriorPoint(g);

							const extent = g.getExtent();
							this.inquadro = (this.inquadro) ? extend(this.inquadro, extent) : extent;
							const feature = new ol.Feature(g);
							feature.setProperties({ dati, idx, interiorPoint, lab });
							return feature;
						}
						else {
							return undefined;
						}
					}
				)
				this.features = this.originalFeatures.filter(
					x => (x != undefined)
				);
				this.mainSource.clear();
				this.mainSource.addFeatures(
					this.features
				);
			}
		}
	}

	indexOfRow(v) {
		return v ? this.dati.indexOf(v) : undefined;
	}

	getStyle(tipo) {
		return stylesMap[tipo];
	}

	evidenzia(row, idx) {
		const selected = this.highFeatures.getArray()[0];
		const newselFeat = this.originalFeatures[idx];
		if (selected != newselFeat) {
			this.highFeatures.getArray().forEach(
				feat => {
					this.highlight.restorePreviousStyle_(feat);
				}
			);
			this.highFeatures.clear();

			if (newselFeat) {
				this.highFeatures.push(newselFeat);
				this.highlight.applySelectedStyle_(newselFeat);
			}
		}
	}
	seleziona(row, idx) {
		//console.log({seleziona: {row, idx}});

		this.mostraOverlay(undefined);

		const selected = this.selFeatures.getArray()[0];
		const newselFeat = this.originalFeatures[idx];
		if (selected != newselFeat) {
			//this.selectedRowIdx = idx;
			if (selected) {
				this.select.restorePreviousStyle_(selected);
				// selected.forEach(
				// 	feat => {
				// 		this.select.restorePreviousStyle_(feat);
				// 	}
				// );
			}
			this.selFeatures.clear();
			if (newselFeat) {
				this.selFeatures.push(newselFeat);
				this.select.applySelectedStyle_(newselFeat);
			}
			this.selectedFeature = newselFeat;
			this.gotoElement(newselFeat);
		}
	}

	gotoElement(element) {
		if (element) {
			const intPoit = element.get('interiorPoint');
			const size = this.mapController.getSize();
			if (intPoit && size) {
				this.view.centerOn(intPoit.getCoordinates(), size, size.map(x => x / 2));
			}
			// this.view.fit(
			// 	element.getGeometry(),
			// 	{
			// 		padding: [100, 100, 100, 100]
			// 	}
			// );
		}
	}


	//mostraOverlay(element) {
	mostraOverlay(element) {
		//const element = (e.selected && e.selected.length == 1) ? e.selected[0] : null;
		//const element = this.selectedElement;

		if (element) {
			if (this.popupOverlay.getPosition() == null) {
				const intPoit = element.get('interiorPoint');
				if (this.popupOverlay && intPoit) {
					this.popupOverlay.setPosition(intPoit.getCoordinates());
					return;
				}
			}
		}
		this.popupOverlay.setPosition(null);
	}
	mostraOverlayAtPoint(point) {
		if (point) {
			this.popupOverlay.setPosition(point.getCoordinates());
			return;
		}
		this.popupOverlay.setPosition(null);
	}

	get selectedRowIdx() {
		const selected = this.selFeatures.getArray()[0];
		if (selected) {
			return selected.get('idx');
		}
		else {
			return undefined;
		}
	}

	drawMap(mapElement, popupElement, conf, dati, context, callBack) {
		if (mapElement && popupElement) {
			this.popupOverlay = new ol.Overlay({
				element: popupElement,
				autoPan: true
			});

			console.log("draw map");
			this.view = new ol.View({
				center: [0, 0],
				zoom: 2,
				//projection: 'EPSG:4326'
				projection: conf.mappa.view.srid// 'EPSG:3857'
			});

			const testWmfLayer = new olLayer.Vector({
					source: new olSource.Vector(
						{
							//regione lazio
							format: new GeoJSON(/*{
									dataProjection: 'EPSG:4326',
									featureProjection: 'EPSG:3857'
								}*/
							),


							// // geoportale minambiente
							// format: new GML3(/*{
							// 		dataProjection: 'EPSG:4326',
							// 		featureProjection: 'EPSG:4326'
							// 	}*/
							// ),


							url: function (extent) {
								return (
									// // costa laghi
									// 'https://geoportale.regione.lazio.it/geoserver/geonode/costa_laghi/wfs?service=WFS&' +
									// 'version=1.1.0&request=GetFeature&typename=geonode:costa_laghi&' +
									// 'outputFormat=application/json&srsname=EPSG:3857&' +
									// 'bbox=' +
									// extent.join(',') +
									// ',EPSG:4326'

									// usi civici
									'https://geoportale.regione.lazio.it/geoserver/geonode/usi_civici/wfs?service=WFS&' +
									'version=1.1.0&request=GetFeature&typename=geonode:usi_civici&' +
									'outputFormat=application/json&srsname=EPSG:3857&' +
									'bbox=' +
									extent.join(',') +
									',EPSG:3857'

									// // boschi
									// 'https://geoportale.regione.lazio.it/geoserver/geonode/boschi/wfs?service=WFS&' +
									// 'version=1.1.0&request=GetFeature&typename=geonode:boschi&' +
									// 'outputFormat=application/json&srsname=EPSG:3857&' +
									// 'bbox=' +
									// extent.join(',') +
									// ',EPSG:4326'





									// // rischio alluvione
									// 'http://wms.pcn.minambiente.it/ogc?map=/ms_ogc/wfs/PAI_rischio.map&service=WFS&' +
									// 'version=1.1.0&request=GetFeature&typename=RN.PAI.RISCHIO.ALLUVIONE&' +
									// 'srsname=EPSG:4326&' +
									// 'bbox=' +
									// //'40.42049804842839933,13.54334090766002419,41.29077240349228362,14.27264548338861161' +
									// extent.join(',') +
									// ',EPSG:4326'
								);
							},
							strategy: tile(createXYZ({ tileSize: 512 })),
						}
					),
					style: new olStyle.Style({
						stroke: new olStyle.Stroke({
							color: 'rgba(0, 0, 255, 1.0)',
							width: 2,
						}),
					}),
				}
			);

			const layers = [
				// // OpenStreetMap
				// new olLayer.Tile(
				// 	{
				// 		source: new OSM(),
				// 		opacity: 0.5
				// 	}
				// ),
				new olLayer.Tile(
					{
						visible: true,
						source: new olSource.XYZ(
							{
								url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
								maxZoom: 20/*,
								projection: 'EPSG:3857'*/
							}
						)
						// source: new olSource.XYZ(
						// 	{
						// 		url: 'http://www.pcn.minambiente.it/arcgis/rest/services/immagini/ortofoto_colore_12/MapServer/tile/{z}/{x}/{y}',
						// 		maxZoom: 20,
						// 		projection: 'EPSG:32633'
						// 	}
						// )



						// // CTR Umbria
						// source: new TileWMS({
						// 	url: 'http://geo.umbriaterritorio.it/arcgis/services/public/CTR_5K/MapServer/WMSServer',
						// 	params: {
						// 		REQUEST: "GetMap",
						// 		//map: "owsofc",
						// 		SRS: "EPSG: 4326",
						// 		FORMAT: "image/png",
						// 		SERVICE: "WMS",
						// 		VERSION: "1.3.0",
						// 		LAYERS: "0",
						// 		TRANSPARENT: 'true'
						// 	},
						// 	serverType: 'geoserver'
						// })

						// // CTR Lazio
						// source: new TileWMS({
						// 	url: 'https://geoportale.regione.lazio.it/geoserver/ows',
						// 	params: {
						// 		REQUEST: "GetMap",
						// 		//map: "ctr_5k_retiled",
						// 		SRS: "EPSG:3857",
						// 		FORMAT: "image/png",
						// 		SERVICE: "WMS",
						// 		VERSION: "1.3.0",
						// 		LAYERS: "geonode:web_050303_sc_dis_a,geonode:web_060106_cl_agr_a,geonode:web_040101_ab_cda_l,geonode:web_040104_af_acq_p,geonode:web_040103_invaso_a,geonode:web_040102_sp_acq_a,geonode:web_020503_op_reg_l,geonode:wms_diga_a,geonode:web_020301_ponte_a,geonode:web_010105_ar_vms_a,geonode:web_010105_ar_vms_l,geonode:web_010103_ac_cic_a,geonode:web_010202_el_fer_l,geonode:web_020201_mn_ind_p,geonode:web_020210_mu_div_a,geonode:web_020212_mn_arr_p,geonode:web_020202_mn_mau_a,geonode:web_020205_man_tr_l,geonode:web_020214_mn_int_p,geonode:web_020202_mn_mau_p,geonode:web_020201_mn_ind_p,geonode:web_070301_tr_ele_l,geonode:wms_edi_min_a,geonode:web_020104_ele_cp_a,geonode:web_040102_sp_acq_l",
						// 		TRANSPARENT: 'true'
						// 	},
						// 	serverType: 'geoserver'
						// })

						// // Particelle catasto
						// source: new TileWMS({
						// 	url: 'https://wms.cartografia.agenziaentrate.gov.it/inspire/wms/ows01.php',
						// 	params: {
						// 		REQUEST: "GetMap",
						// 		//map: "ctr_5k_retiled",
						// 		CRS: "EPSG:4258",
						// 		FORMAT: "image/png",
						// 		SERVICE: "WMS",
						// 		VERSION: "1.1.0",
						// 		LAYERS: "CP.CadastralZoning,strade,acque,CP.CadastralParcel,vestizioni"//,fabbricati
						// 	},
						// 	projection: 'EPSG:4258',
						// 	serverType: 'geoserver'
						// })

						// // Ortofoto 2012 - 33
						// source: new TileWMS({
						// 	url: 'http://wms.pcn.minambiente.it/ogc?map=/ms_ogc/WMS_v1.3/raster/ortofoto_colore_12.map',
						// 	params: {
						// 		REQUEST: "GetMap",
						// 		//map: "ctr_5k_retiled",
						// 		CRS: "EPSG:32632",
						// 		FORMAT: "image/png",
						// 		SERVICE: "WMS",
						// 		VERSION: "1.3.0",
						// 		LAYERS: "OI.ORTOIMMAGINI.2012.33",
						// 		TRANSPARENT: 'true'
						// 	},
						// 	projection: 'EPSG:32633',
						// 	serverType: 'geoserver'
						// }),

						// // Ortofoto 2012 - 32
						// source: new TileWMS({
						// 	url: 'http://wms.pcn.minambiente.it/ogc?map=/ms_ogc/WMS_v1.3/raster/ortofoto_colore_12.map',
						// 	params: {
						// 		REQUEST: "GetMap",
						// 		//map: "ctr_5k_retiled",
						// 		CRS: "EPSG:32632",
						// 		FORMAT: "image/png",
						// 		SERVICE: "WMS",
						// 		VERSION: "1.3.0",
						// 		LAYERS: "OI.ORTOIMMAGINI.2012.32",
						// 		TRANSPARENT: 'true'
						// 	},
						// 	projection: 'EPSG:32632',
						// 	serverType: 'geoserver'
						// })

					}
				)//,
				//testWmfLayer,
			];


			if (context.shapeEnte) {
				const viewSrid = conf.mappa.view.srid;
				const shapeSrid = `EPSG:${context.sridShapeEnte}`;
				const opts =  (shapeSrid == undefined) ? undefined : { dataProjection: shapeSrid, featureProjection: viewSrid };

				const vectorLimiti = new olSource.Vector();
				vectorLimiti.addFeature(
					new ol.Feature({
						geometry: format.readGeometry(
							context.shapeEnte, opts
						),
						name: 'Limiti',
					  })
				);
				const layerLimiti = new olLayer.Vector({
					source: vectorLimiti,
					style: new olStyle.Style({
						stroke: new olStyle.Stroke({
							color: 'rgba(255, 255, 0, 1.0)',
							width: 2,
						}),
					})
				});
				layers.push(layerLimiti);
			}



			layers.push(this.mainLayer);

			this.inquadro = undefined;
			this.updateData(conf, dati);

			if (this.inquadro == undefined && context.boxInquadrEnte) {
				// posizionamento sui limiti amministrativi per istanze senza geometrie associate
				const viewSrid = conf.mappa.view.srid;
				const shapeSrid = `EPSG:${context.sridShapeEnte}`;
				const opts =  (shapeSrid == undefined) ? undefined : { dataProjection: shapeSrid, featureProjection: viewSrid };

				const g = format.readGeometry(
					context.boxInquadrEnte//, opts
				);
				if (g != undefined) {

					if (opts != undefined) {
						g.transform(shapeSrid, viewSrid);
					}
					const extent = g.getExtent();
					this.inquadro = extent;
				}
			}
			console.log({inquadro: this.inquadro});

			//this.currentInteractions = [this.highlight, this.select];

			const mapInteractions = olInteraction.defaults();
			this.mapController = new ol.Map(
				{
					layers: layers,
					target: mapElement,
					view: this.view,
					overlays: [this.popupOverlay],
					interactions: mapInteractions
				}
			);
			this.setInteractions([this.highlight, this.select]);
			if (this.inquadro) {
				this.view.fit(
					this.inquadro,
					{
						callback: callBack,
						padding: [10, 10, 10, 10]
					}
				);
			}
			else {
				callBack();
			}
		}
	}
}
