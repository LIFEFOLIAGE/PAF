import { BaseMap, stylesMap, hexToRGB } from "./base-map";

import TileLayer from 'ol/layer/Tile';
import XYZ from 'ol/source/XYZ';
import VectorSource from 'ol/source/Vector';
import VectorLayer from 'ol/layer/Vector';
import WKT from 'ol/format/WKT';
const format = new WKT();
import {Style, Stroke, Text, Fill } from 'ol/style';
import {
	Pointer as PointerInteraction,
	defaults as defaultInteractions,
	Interaction,
	KeyboardPan,
} from 'ol/interaction';
import { extend } from 'ol/extent';
import Map from 'ol/Map';
import {Draw, Modify, Snap, Select, Translate} from 'ol/interaction';
import OSM from 'ol/source/OSM';
import Group from 'ol/layer/Group';
import View from 'ol/View';
import { ScaleLine, ZoomSlider, defaults as defaultControls } from 'ol/control';
import { get as getProjection } from 'ol/proj';
import { Collection, Feature, Overlay } from 'ol';
import { Scheda } from '../components/shared/editor-scheda/editor-scheda.component';
import MapBrowserEvent from 'ol/MapBrowserEvent';
import { SelectEvent } from 'ol/interaction/Select';
import { Geometry } from 'ol/geom';
import EventType from 'ol/events/EventType';


import {
	Point,
	LineString,
	LinearRing,
	Polygon,
	MultiPoint,
	MultiLineString,
	MultiPolygon,
	GeometryCollection
} from "ol/geom";

//import * as geom from 'jsts/org/locationtech/jts/geom';
//import * as jsts from 'jsts';
import * as geom from 'jsts/org/locationtech/jts/geom';
import * as operation from 'jsts/org/locationtech/jts/operation';
import * as io from 'jsts/org/locationtech/jts/io';
import OverlayOp from 'jsts/org/locationtech/jts/operation/overlay/OverlayOp';
import { unByKey } from "ol/Observable";
import { retryWhen } from "rxjs";

const jsts = {
	geom: geom,
	operation: operation,
	io: io,
	OverlayOp: OverlayOp
};


const parser = new jsts.io.OL3Parser();

parser.inject(Point, LineString, LinearRing, Polygon, MultiPoint, MultiLineString, MultiPolygon, GeometryCollection);
const stringWriter = new jsts.io.WKTWriter();

class DrawAbortOnEscape extends Interaction {
	draw = undefined;
	constructor(draw, options) {
		super();
		this.draw = draw;
	}
	handleEvent(mapBrowserEvent) {
		if (this.draw && (mapBrowserEvent.type == EventType.KEYDOWN || mapBrowserEvent.type == EventType.KEYPRESS)) {
			const keyEvent = (
				mapBrowserEvent.originalEvent
			);
			const key = keyEvent.key;
			if (key == 'Escape') {
				this.draw.abortDrawing();
				mapBrowserEvent.preventDefault(); 
				return false;
			}
		}
		return true;
	}
}


export class InteractiveMap extends BaseMap {

	constructor(selectCb, highilightCb) {
		super(selectCb, highilightCb);
	}

	holingFeature = undefined;
	coordsLenth = undefined;

	drawInteraction = undefined;
	drawAbortInteraction = undefined;
	modifyInteraction = undefined;
	moveInteraction = undefined;

	drawVectorSource = undefined;
	drawLayer = undefined;
	cutVectorSource = undefined;
	cutVectorSource = undefined;

	onGeomChange = (e) => {
		let linear_ring = new LinearRing(e.target.getCoordinates()[0]);
		let coordinates = this.holingFeature.getGeometry().getCoordinates();
		let geom = new Polygon(coordinates.slice(0, this.coordsLenth));
		geom.appendLinearRing(linear_ring);
		this.holingFeature.setGeometry(geom);
	}

	setCut() {
		this.drawInteraction = new Draw(
			{
				source: this.drawVectorSource,
				type: "LineString"
			}
		);
		this.drawAbortInteraction = new DrawAbortOnEscape(this.drawInteraction, {});
		this.setInteractions([this.drawInteraction, this.drawAbortInteraction]);
	}

	setDrawing(gomeType) {
		this.drawInteraction = new Draw(
			{
				source: this.drawVectorSource,
				//type: "Polygon",
				type: gomeType
			}
		);
		if (gomeType == "Polygon") {
			let undoGeomChange = undefined;
			this.drawInteraction.on(
				'drawstart',
				(e) => {
					const drawingGeom = e.feature.getGeometry();
					this.holingFeature = undefined;
					this.drawVectorSource.forEachFeatureIntersectingExtent(
						drawingGeom.getExtent(), 
						(f) => {
							const type = f.getGeometry().getType();
							if (type == "Polygon") {
								this.holingFeature = f;
							}
						
						}
					);
					if (this.holingFeature) {
						this.coordsLenth = this.holingFeature.getGeometry().getCoordinates().length;
						undoGeomChange = drawingGeom.on('change', this.onGeomChange);
					}
				}
			);
			this.drawInteraction.on(
				'drawend',
				(e) => {
					if (this.holingFeature) {
						this.holingFeature = undefined;
						if (undoGeomChange) {
							unByKey(undoGeomChange);
							undoGeomChange = undefined;
						}
						setTimeout(
							() => {
								this.drawVectorSource.removeFeature(e.feature);
							},
							5
						);
					}
				}
			);
		}
		this.drawAbortInteraction = new DrawAbortOnEscape(this.drawInteraction, {});
		this.setInteractions([this.drawInteraction, this.drawAbortInteraction, this.modifyInteraction, this.moveInteraction]);
	}

	startJoin(idx) {
		if (idx != undefined) {
			this.updatingFeature = this.originalFeatures[idx];
			if (this.updatingFeature) {
				this.mainSource.removeFeature(this.updatingFeature);

				this.selectionFeatSource = new VectorSource(
					{
						wrapX: false
					}
				);
				this.selectionFeatSource.addFeature(this.updatingFeature);

				this.selectionFeatLayer = new VectorLayer(
					{
						source: this.selectionFeatSource,
						visible: true,
						style: new Style(
							{
								fill: new Fill({
									color: hexToRGB('#00FF00', 0.8)
								}),
								stroke: new Stroke({
									color: '#00FF00',
									width: 1
								})
							}
						)
					}
				);
				this.mapController.addLayer(this.selectionFeatLayer);

				this.selGeomFeatures = new Collection();

				this.selectionFeat = new Select(
					{
						layers: [this.mainLayer],
						features: this.selGeomFeatures,
						style: new Style(
							{
								fill: new Fill({
									color: hexToRGB('#FFFF00', 0.8)
								}),
								stroke: new Stroke({
									color: '#FFFF00',
									width: 1
								})
							}
						)
					}
				);


				this.setInteractions([this.selectionFeat]);

			}
			else {
				throw Error(`Missing cut element at ${idx} position`);
			}
		}
		else {
			throw Error("Missing cut element index");
		}
	}

	stopJoin() {
		if (this.updatingFeature) {
			this.mainSource.addFeature(this.updatingFeature);
			//this.seleziona(this.updatingFeature.get('dati'), this.updatingFeature.get('idx'));
			this.updatingFeature = undefined;
		}
		this.restoreInteractions();
		if (this.selectionFeat) {
			this.selectionFeat.dispose();
			this.selectionFeat = undefined;
		}
		if (this.selGeomFeatures) {
			this.selGeomFeatures.clear();
			this.selGeomFeatures.dispose();
			this.selGeomFeatures = undefined;
		}
		if (this.selectionFeatLayer) {
			this.selectionFeatLayer.dispose();
			this.selectionFeatLayer = undefined;
		}
		if (this.selectionFeatSource) {
			this.selectionFeatSource.clear();
			this.selectionFeatSource.dispose();
			this.selectionFeatSource = undefined;
		}
	}

	startDisjoint(idx) {
		if (idx != undefined) {
			this.updatingFeature = this.originalFeatures[idx];
			if (this.updatingFeature) {
				const geom = this.updatingFeature.getGeometry();
				const gType = geom.getType();
				let arrGeom = undefined;
				switch (gType) {
					case "GeometryCollection": {
						arrGeom = geom.getGeometries();
					};break;
					case "MultiPoint": {
						arrGeom = geom.getPoints();
					};break;
					case "MultiLineString": {
						arrGeom = geom.getLineStrings();
					};break;
					case "MultiPolygon": {
						arrGeom = geom.getPolygons();
					};break;
					default: {
						return false;
					}
				}
				this.mainSource.removeFeature(this.updatingFeature);
				this.selGeomFeatures = new Collection();
				this.selectionFeatSource = new VectorSource(
					{
						wrapX: false,
						features: arrGeom.map(g => new Feature(g))
					}
				);
				this.selectionFeatLayer = new VectorLayer(
					{
						source: this.selectionFeatSource,
						visible: true
					}
				);
				this.mapController.addLayer(this.selectionFeatLayer);

				this.selectionFeat = new Select(
					{
						layers: [this.selectionFeatLayer],
						features: this.selGeomFeatures
					}
				);

				this.setInteractions([this.selectionFeat]);
				return true;
			}
			else {
				throw Error(`Missing cut element at ${idx} position`);
			}
		}
		else {
			throw Error("Missing cut element index");
		}
	}

	startCut(idx) {
		if (idx != undefined) {
			this.updatingFeature = this.originalFeatures[idx];
			if (this.updatingFeature) {
				this.drawVectorSource = new VectorSource(
					{
						wrapX: false
					}
				);
				this.cutVectorSource = new VectorSource(
					{
						wrapX: false
					}
				);
				const geom = this.updatingFeature.getGeometry();
				const gType = geom.getType();
				switch (gType) {
					// case "Polygon": {
					// 	this.drawVectorSource.addFeature(this.updatingFeature.clone());
					// }; break;
					case "MultiPolygon": {
						this.cutVectorSource.addFeatures(geom.getPolygons().map(p => new Feature(p)));
					}; break;
					case "GeometryCollection": {
						this.cutVectorSource.addFeatures(geom.getGeometries().map(g => new Feature(g)));
					}; break;
					default: {
						this.cutVectorSource.addFeature(this.updatingFeature.clone());
					}
				}

				this.mainSource.removeFeature(this.updatingFeature);

				this.cutLayer = new VectorLayer(
					{
						source: this.cutVectorSource,
						visible: true
					}
				);
				this.drawLayer = new VectorLayer(
					{
						source: this.drawVectorSource,
						visible: true
					}
				);

				this.mapController.addLayer(this.cutLayer);
				this.mapController.addLayer(this.drawLayer);
				this.setCut();
			}
			else {
				throw Error(`Missing cut element at ${idx} position`);
			}
		}
		else {
			throw Error("Missing cut element index");
		}
	}

	startDrawing(geomType, idx) {
		this.drawVectorSource = new VectorSource(
			{
				wrapX: false
			}
		);
		if (idx != undefined) {
			this.updatingFeature = this.originalFeatures[idx];
			if (this.updatingFeature) {
				this.mainSource.removeFeature(this.updatingFeature);
				const geom = this.updatingFeature.getGeometry();
				const gType = geom.getType();
				switch (gType) {
					// case "Polygon": {
					// 	this.drawVectorSource.addFeature(this.updatingFeature.clone());
					// }; break;
					case "MultiPolygon": {
						this.drawVectorSource.addFeatures(geom.getPolygons().map(p => new Feature(p)));
					}; break;
					case "GeometryCollection": {
						this.drawVectorSource.addFeatures(geom.getGeometries().map(g => new Feature(g)));
					}; break;
					default: {
						this.drawVectorSource.addFeature(this.updatingFeature.clone());
					}
				}
			}
			else {
				throw new Error(`Geometria in posizione ${idx} mancante`);
			}
		}
		else {
			this.updatingFeature = undefined;
		}
		this.drawLayer = new VectorLayer(
			{
				source: this.drawVectorSource,
				visible: true
			}
		);

		this.modifyInteraction = new Modify(
			{
				source: this.drawVectorSource,
				condition: (ev) => {
					const keyEvent = (
						ev.originalEvent
					);
					return !keyEvent.altKey && keyEvent.ctrlKey;
				}
			}
		);
		
		this.moveInteraction = new Translate(
			{
				layers: [this.drawLayer],
				condition: (ev) => {
					const keyEvent = (
						ev.originalEvent
					);
					return keyEvent.altKey && !keyEvent.ctrlKey;
				}
			}
		);

		this.mapController.addLayer(this.drawLayer);

		this.setDrawing(geomType);
	}
	changeDrawingMode(mode) {
		this.drawInteraction.abortDrawing();
		this.setDrawing(mode);	
	}
	stopDisjoint() {
		this.restoreInteractions();
		if (this.updatingFeature) {
			this.mainSource.addFeature(this.updatingFeature);
			//this.seleziona(this.updatingFeature.get('dati'), this.updatingFeature.get('idx'));
			this.updatingFeature = undefined;
		}
		if (this.selectionFeat) {
			this.selectionFeat.dispose();
			this.selectionFeat = undefined;
		}
		if (this.selGeomFeatures) {
			this.selGeomFeatures.dispose();
		}
		if (this.selectionFeatLayer) {
			this.mapController.removeLayer(this.selectionFeatLayer);
			this.selectionFeatLayer.dispose();
			this.selectionFeatLayer = undefined;
		}
		if (this.selectionFeatSource) {
			this.selectionFeatSource.clear();
			this.selectionFeatSource.dispose();
			this.selectionFeatSource = null;
		}
	}
	restoreInteractions() {
		this.setInteractions([this.highlight, this.select]);
	}
	stopDrawing() {
		this.restoreInteractions();
		if (this.drawAbortInteraction) {
			this.drawAbortInteraction.dispose();
			this.drawAbortInteraction = undefined;
		}
		if (this.drawInteraction) {
			this.drawInteraction.dispose();
			this.drawInteraction = undefined;
		}
		if (this.moveInteraction) {
			this.moveInteraction.dispose();
			this.moveInteraction = undefined;
		}
		if (this.modifyInteraction) {
			this.modifyInteraction.dispose();
			this.modifyInteraction = undefined;
		}
		if (this.cutLayer) {
			this.mapController.removeLayer(this.cutLayer);
			this.cutLayer.dispose();
			this.cutLayer = undefined;
		}
		if (this.cutVectorSource) {
			this.cutVectorSource.clear();
			this.cutVectorSource.dispose();
			this.cutVectorSource = undefined;
		}
		if (this.drawLayer) {
			this.mapController.removeLayer(this.drawLayer);
			this.drawLayer.dispose();
			this.drawLayer = undefined;
		}
		if (this.drawVectorSource) {
			this.drawVectorSource.clear();
			this.drawVectorSource.dispose();
			this.drawVectorSource = undefined;	
		}
		if (this.updatingFeature) {
			this.mainSource.addFeature(this.updatingFeature);
			//this.select.restorePreviousStyle_(this.updatingFeature);
			//this.seleziona(this.updatingFeature.get('dati'), this.updatingFeature.get('idx'));
			this.updatingFeature = undefined;
		}
	}

	getUnionGeom(featArr) {
		if (featArr.length > 0) {
			const olGeomsArr = featArr.map(f => f.getGeometry());
			const jstGeomArr = olGeomsArr.map(x => parser.read(x));
			const geomFact = new jsts.geom.GeometryFactory();
			const geomColl = new jsts.geom.GeometryCollection(jstGeomArr, geomFact);
			const unaryUnion = new jsts.operation.union.UnaryUnionOp(geomColl, geomFact);
			const unionGeom = unaryUnion.union();
			const geom = parser.write(unionGeom);
			return unionGeom;
			// return {
			// 	wkt: stringWriter.write(unionGeom),
			// 	//feat,
			// 	interiorPoint: this.getInteriorPoint(geom)
			// };
		}
		else {
			return undefined;
		}
	}
	getJointFeatures() {
		const src = this.selGeomFeatures;
		if (src && this.updatingFeature) {
			const arrFeat = src.getArray();
			return {
				newWkt: stringWriter.write(this.getUnionGeom(arrFeat.concat(this.updatingFeature))),
				deletes: arrFeat.map(feat => feat.get('idx'))
			};
		}
		else {
			return {
				newWkt: undefined,
				deletes: undefined
			};
		}
	}
	getDisjointFeatures() {
		const src = this.selGeomFeatures;
		if (src) {
			const groupA = src.getArray();
			groupA.forEach(
				feat => this.selectionFeatSource.removeFeature(feat)
			);
			const groupB = this.selectionFeatSource.getFeatures();


			return [
				stringWriter.write(this.getUnionGeom(groupA)),
				stringWriter.write(this.getUnionGeom(groupB))
			];
		}
		else {
			return [undefined, undefined];
		}

	}
	getCutFeatures() {
		const src = this.drawVectorSource;
		if (src) {
			// const olGeomsArr = src.getFeatures().map(f => f.getGeometry());
			// const jstGeomArr = olGeomsArr.map(x => parser.read(x));
			// const geomFact = new jsts.geom.GeometryFactory();
			// const geomColl = new jsts.geom.GeometryCollection(jstGeomArr, geomFact);


			const splitLines = this.drawVectorSource.getFeatures();

			const res = [];
			
			function addPolygon (originalGeom, addGeom, i) {
				if (addGeom instanceof jsts.geom.Polygon) {
					if (addGeom.getArea && addGeom.getArea() > 0 ) {
						console.log(`divided ${i}: ${stringWriter.write(addGeom)}`);
						console.log(`original ${i}: ${stringWriter.write(originalGeom)}`);
						console.log(addGeom);
		
						//this.sourceD.addFeature(new Feature(parser.write(addGeom)));
						//const olGeom = parser.write(addGeom)
						res.push(
							{
								wkt: stringWriter.write(addGeom),
								interiorPoint: undefined
							}
						);
					}
				}
				else {
					const n = addGeom.getNumGeometries();
					if (n > 1) {
						for (let j = 0; j < n; j++) {
							const g = addGeom.getGeometryN(j);
							if (g != addGeom) {
								addPolygon(originalGeom, g, j);
							}
						}
					}
				}
			}
			
			this.cutVectorSource.getFeatures().forEach(
				mainFeat => {
					const olGeom = mainFeat.getGeometry();
					const type = olGeom.getType();
					const mainGeom = parser.read(olGeom);

					switch (type) {
						case "Polygon": {
							const ring = mainGeom.getExteriorRing()
				
							const splitGeoms = splitLines.map(
								(x, i) => {
									const g = parser.read(x.getGeometry());
									//console.log(`cut ${i}: ${stringWriter.write(g)}`);
									return g;
								}
							);
							
							const lineMerger = new jsts.operation.linemerge.LineMerger();
				
							lineMerger.add(ring);
				
							splitGeoms.forEach(
							  x => {
								lineMerger.add(x);
							  }
							);
				
							
							const mergeRes = lineMerger.getMergedLineStrings();
							// mergeRes.toArray().forEach(
							// 	(x, i) => {
							// 		console.log(`merge ${i}: ${stringWriter.write(x)}`);
							// 	}
							// );
				
							const unaryUnion = new jsts.operation.union.UnaryUnionOp(mergeRes);
							console.log(unaryUnion);
							const unionGeom = unaryUnion.union();
							
							
							//console.log(`union: ${stringWriter.write(unionGeom)}`);
				
							
							const poligonizer = new jsts.operation.polygonize.Polygonizer();
							poligonizer.add(unionGeom);
							const divided = poligonizer.getPolygons();
							console.log(divided);
				
				
							divided.toArray().forEach(
								(x, i) => {
									const y = jsts.OverlayOp.intersection(x, mainGeom);
									addPolygon(x, y, i);
									
								}
							);
						}; break;
						case "LineString": {
							res.push(
								{
									wkt: stringWriter.write(mainGeom),
									interiorPoint: olGeom
								}
							);
						}; break;
						case "Point": {
							res.push(
								{
									wkt: stringWriter.write(mainGeom),
									interiorPoint: olGeom
								}
							);
						}; break;
					}
				}
			);

			return res;
		}
		else {
			throw new Error("Null source");
		}
	}

	getDrawnFeatures() {
		const src = this.drawVectorSource;
		if (src) {
			// const olGeomsArr = src.getFeatures().map(f => f.getGeometry());
			// const jstGeomArr = olGeomsArr.map(x => parser.read(x));
			// const geomFact = new jsts.geom.GeometryFactory();
			// const geomColl = new jsts.geom.GeometryCollection(jstGeomArr, geomFact);
			// const unaryUnion = new jsts.operation.union.UnaryUnionOp(geomColl, geomFact);
			// console.log(unaryUnion);
			// const unionGeom = unaryUnion.union();
			// const geom = parser.write(unionGeom);
			
			// return {
			// 	wkt: stringWriter.write(unionGeom),
			// 	//feat,
			// 	interiorPoint: this.getInteriorPoint(geom)
			// };
			const geom = this.getUnionGeom(src.getFeatures());
			return {
				wkt: stringWriter.write(geom),
				interiorPoint: this.getInteriorPoint(parser.write(geom))
			};
		}
		else {
			throw new Error("Null source");
		}
	}
}